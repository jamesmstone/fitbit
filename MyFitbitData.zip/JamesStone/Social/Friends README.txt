Friend Data Export

This portion of your data export includes all of the Fitbit users you are friends with.

Each row represents one friend, like so:
----------

    id                  - the id of the friend
    name                - the name of the friend
    timestamp           - the time the friendship was created
